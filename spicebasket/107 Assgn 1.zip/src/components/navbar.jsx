
import "./navbar.css";

function Navbar(){
    return (
    <div className="navbar">
        <h1>Menu will be here</h1>
        </div>
    );
}

export default Navbar;


